import 'package:flutter/material.dart';

// Example hostel model (replace with your API or database model)
class Hostel {
  final int id;
  final String name;
  final String address;
  final String town;
  final String schoolName;
  final String schoolShortName;
  final String imageUrl;
  final double minPrice;
  final double maxPrice;
  final int roomsAvailable;

  Hostel({
    required this.id,
    required this.name,
    required this.address,
    required this.town,
    required this.schoolName,
    required this.schoolShortName,
    required this.imageUrl,
    required this.minPrice,
    required this.maxPrice,
    required this.roomsAvailable,
  });
}

class HostelsList extends StatefulWidget {
  const HostelsList({super.key});

  @override
  State<HostelsList> createState() => _HostelsListState();
}

class _HostelsListState extends State<HostelsList> {
  // Simulated data (replace with API call)
  List<Hostel> hostels = [];
  List<Hostel> filteredHostels = [];
  bool isSearching = false;
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // TODO: Fetch hostels from API instead of hardcoded
    hostels = List.generate(
      6,
      (index) => Hostel(
        id: index,
        name: 'Hostel ${index + 1}',
        address: '123 Street',
        town: 'Town ${index + 1}',
        schoolName: 'University ${index + 1}',
        schoolShortName: 'U${index + 1}',
        imageUrl: 'assets/images/hostel.jpg',
        minPrice: 300 + index * 50,
        maxPrice: 400 + index * 50,
        roomsAvailable: index + 1,
      ),
    );

    filteredHostels = hostels;
  }

  void onSearch(String query) {
    setState(() {
      if (query.isEmpty) {
        isSearching = false;
        filteredHostels = hostels;
      } else {
        isSearching = true;
        filteredHostels = hostels
            .where((h) =>
                h.name.toLowerCase().contains(query.toLowerCase()) ||
                h.town.toLowerCase().contains(query.toLowerCase()) ||
                h.schoolName.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  String getPriceDisplay(Hostel h) {
    return (h.minPrice == h.maxPrice)
        ? "₵${h.minPrice.toStringAsFixed(2)}"
        : "₵${h.minPrice.toStringAsFixed(2)} - ₵${h.maxPrice.toStringAsFixed(2)}";
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        /// Hostels Grid
        filteredHostels.isEmpty
            ? const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Center(
                  child: Text(
                    'No hostels available.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              )
            : GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filteredHostels.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount:
                      MediaQuery.of(context).size.width > 1200 ? 3 : 1,
                  childAspectRatio: 0.75,
                  mainAxisSpacing: 24,
                  crossAxisSpacing: 24,
                ),
                itemBuilder: (context, index) {
                  final hostel = filteredHostels[index];
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    elevation: 4,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        /// Image
                        ClipRRect(
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(20)),
                          child: Image.asset(
                            hostel.imageUrl,
                            height: 180,
                            fit: BoxFit.cover,
                          ),
                        ),

                        /// Info
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            children: [
                              Text(
                                hostel.name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                hostel.address,
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12),
                                textAlign: TextAlign.center,
                              ),
                              Text(
                                '${hostel.town}, Ghana',
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 4),
                              if (hostel.schoolName.isNotEmpty)
                                Text(
                                  '${hostel.schoolName} (${hostel.schoolShortName})',
                                  style: const TextStyle(
                                      color: Colors.blue, fontSize: 12),
                                  textAlign: TextAlign.center,
                                ),
                              const SizedBox(height: 8),
                              Text(
                                getPriceDisplay(hostel),
                                style: const TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                hostel.roomsAvailable > 0
                                    ? '${hostel.roomsAvailable} room${hostel.roomsAvailable > 1 ? 's' : ''} available'
                                    : 'No rooms available yet',
                                style: const TextStyle(color: Colors.grey),
                              ),
                              const SizedBox(height: 12),
                              ElevatedButton(
                                onPressed: () {
                                  // TODO: Navigate to hostel detail screen
                                  print('See details of hostel ${hostel.id}');
                                },
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(50)),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 12, horizontal: 24),
                                ),
                                child: const Text('See Details'),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ],
    );
  }
}
