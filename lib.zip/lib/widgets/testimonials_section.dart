import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class TestimonialsSection extends StatefulWidget {
  const TestimonialsSection({super.key});

  @override
  State<TestimonialsSection> createState() => _TestimonialsSectionState();
}

class _TestimonialsSectionState extends State<TestimonialsSection> {
  final CarouselSliderController _controller = CarouselSliderController();

  final List<Map<String, String>> _testimonials = [
    {
      'name': 'James Smith',
      'role': 'Student, Technical University (HTU)',
      'image':
          'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      'quote':
          'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.',
    },
    {
      'name': 'Mike Houston',
      'role': 'Student, University of Health and Allied Sciences (UHAS)',
      'image':
          'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      'quote':
          'Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.',
    },
    {
      'name': 'Cameron Webster',
      'role': 'Lecturer, Ho Technical University',
      'image':
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      'quote':
          'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.',
    },
    {
      'name': 'Dave Smith',
      'role': 'Student, Technical University (HTU)',
      'image':
          'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      'quote':
          'Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final textPrimary = theme.textTheme.bodyMedium?.color ?? Colors.black;
    final textSecondary = theme.textTheme.bodySmall?.color ?? Colors.grey;
    final surfaceColor = theme.cardColor;

    // Adaptive card width
    double cardWidth;
    if (screenWidth < 600) {
      cardWidth = screenWidth * 0.8;
    } else if (screenWidth < 1200) {
      cardWidth = screenWidth * 0.45;
    } else {
      cardWidth = screenWidth * 0.3;
    }

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 60, horizontal: 24),
      color: surfaceColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Header ─────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Customer Says',
                style: TextStyle(
                  fontSize: screenWidth < 600 ? 22 : 28,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.primary,
                ),
              ),
            ],
          ),

          const SizedBox(height: 40),

          // ── Carousel Slider ─────────────────
          CarouselSlider(
            carouselController: _controller,
            options: CarouselOptions(
              height: 300,
              viewportFraction: cardWidth / screenWidth,
              autoPlay: true,
              autoPlayInterval: const Duration(seconds: 5),
              enlargeCenterPage: true,
              enableInfiniteScroll: true,
            ),
            items: _testimonials
                .map(
                  (t) => _TestimonialCard(
                    name: t['name']!,
                    role: t['role']!,
                    image: t['image']!,
                    quote: t['quote']!,
                    textPrimary: textPrimary,
                    textSecondary: textSecondary,
                    surfaceColor: surfaceColor,
                    width: cardWidth,
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }
}

extension on CarouselSliderController {}

/// Modern navigation button
// ignore: unused_element
class _NavButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _NavButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        padding: EdgeInsets.symmetric(
          horizontal: isMobile ? 12 : 16,
          vertical: isMobile ? 8 : 10,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
      child: Text(label),
    );
  }
}

/// Individual testimonial card
class _TestimonialCard extends StatelessWidget {
  final String name;
  final String role;
  final String image;
  final String quote;
  final Color textPrimary;
  final Color textSecondary;
  final Color surfaceColor;
  final double width;

  const _TestimonialCard({
    required this.name,
    required this.role,
    required this.image,
    required this.quote,
    required this.textPrimary,
    required this.textSecondary,
    required this.surfaceColor,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 32,
            backgroundImage: NetworkImage(image),
          ),
          const SizedBox(height: 12),
          Row(
            children: List.generate(
              5,
              (i) =>
                  const Icon(Icons.star_rounded, color: Colors.amber, size: 18),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            name,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Text(
              '"$quote"',
              style: TextStyle(
                fontSize: 12,
                color: textSecondary,
                height: 1.6,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 5,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            role,
            style: TextStyle(
              fontSize: 11,
              color: textSecondary.withOpacity(0.7),
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
