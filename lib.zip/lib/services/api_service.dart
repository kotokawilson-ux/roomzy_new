// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/models.dart';
import '../core/constants/app_constants.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Internal helper — parses every response the same way.
// Every PHP endpoint uses sendJson(bool, data, message) so the shape is always:
//   { "success": true/false, "data": ..., "message": "..." }
// ─────────────────────────────────────────────────────────────────────────────
Map<String, dynamic> _parseResponse(http.Response response) {
  if (response.statusCode != 200) {
    throw ApiException('Server error ${response.statusCode}');
  }
  final body = json.decode(response.body);
  if (body is! Map<String, dynamic>) {
    throw const ApiException('Unexpected response format');
  }
  if (body['success'] != true) {
    throw ApiException(body['message']?.toString() ?? 'Unknown server error');
  }
  return body;
}

// ─────────────────────────────────────────────────────────────────────────────
// Typed exception so callers can catch API errors separately from network errors
// ─────────────────────────────────────────────────────────────────────────────
class ApiException implements Exception {
  final String message;
  const ApiException(this.message);

  @override
  String toString() => 'ApiException: $message';
}

// ─────────────────────────────────────────────────────────────────────────────
// Default headers sent with every request
// ─────────────────────────────────────────────────────────────────────────────
const Map<String, String> _headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
};

// ─────────────────────────────────────────────────────────────────────────────
// ApiService
// All methods are static — call them directly: ApiService.getFeaturedHostels()
// ─────────────────────────────────────────────────────────────────────────────
class ApiService {
  ApiService._(); // prevent instantiation

  static const String _base = AppConstants.baseUrl;
  static const Duration _timeout = Duration(seconds: 20);

  // ───────────────────────────────────────────────────────────────────────────
  // HOSTELS
  // ───────────────────────────────────────────────────────────────────────────

  /// Top 10 hostels for the home screen (with price range + school join).
  static Future<List<Hostel>> getFeaturedHostels() async {
    final res = await http
        .get(Uri.parse('$_base/get_featured_hostels.php'), headers: _headers)
        .timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Hostel.fromJson(e)).toList();
  }

  /// All hostels — supports optional filters passed as query params.
  ///   townFilter    → ?town=Kumasi
  ///   schoolFilter  → ?school_id=3
  ///   search        → ?search=legacy
  static Future<List<Hostel>> getHostels({
    String? townFilter,
    int? schoolFilter,
    String? search,
  }) async {
    final params = <String, String>{};
    if (townFilter != null && townFilter.isNotEmpty) {
      params['town'] = townFilter;
    }
    if (schoolFilter != null) params['school_id'] = schoolFilter.toString();
    if (search != null && search.isNotEmpty) params['search'] = search;

    final uri =
        Uri.parse('$_base/get_hostels.php').replace(queryParameters: params);
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Hostel.fromJson(e)).toList();
  }

  /// Single hostel by ID.
  static Future<Hostel> getHostelById(int id) async {
    final uri = Uri.parse('$_base/get_hostel.php').replace(
      queryParameters: {'id': id.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    return Hostel.fromJson(body['data']);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // ROOMS
  // ───────────────────────────────────────────────────────────────────────────

  /// All rooms for a given hostel.
  static Future<List<Room>> getRooms(int hostelId) async {
    final uri = Uri.parse('$_base/get_rooms.php').replace(
      queryParameters: {'hostel_id': hostelId.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Room.fromJson(e)).toList();
  }

  /// Single room by ID.
  static Future<Room> getRoomById(int id) async {
    final uri = Uri.parse('$_base/get_room.php').replace(
      queryParameters: {'id': id.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    return Room.fromJson(body['data']);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // BOOKINGS
  // ───────────────────────────────────────────────────────────────────────────

  /// Submit a new booking.
  static Future<Booking> createBooking(Map<String, dynamic> payload) async {
    final res = await http
        .post(
          Uri.parse('$_base/create_booking.php'),
          headers: _headers,
          body: json.encode(payload),
        )
        .timeout(_timeout);

    final body = _parseResponse(res);
    return Booking.fromJson(body['data']);
  }

  /// Get all bookings for a student by email.
  static Future<List<Booking>> getBookingsByEmail(String email) async {
    final uri = Uri.parse('$_base/get_bookings.php').replace(
      queryParameters: {'email': email},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Booking.fromJson(e)).toList();
  }

  /// Get all bookings for a landlord by hostel code.
  static Future<List<Booking>> getBookingsByHostel(String hostelCode) async {
    final uri = Uri.parse('$_base/get_bookings.php').replace(
      queryParameters: {'hostel_code': hostelCode},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Booking.fromJson(e)).toList();
  }

  /// Update booking status (e.g. 'confirmed', 'cancelled').
  static Future<bool> updateBookingStatus(int bookingId, String status) async {
    final res = await http
        .post(
          Uri.parse('$_base/update_booking.php'),
          headers: _headers,
          body: json.encode({'id': bookingId, 'status': status}),
        )
        .timeout(_timeout);

    _parseResponse(res); // throws on failure
    return true;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // SCHOOLS
  // ───────────────────────────────────────────────────────────────────────────

  /// All schools — used for filter dropdowns.
  static Future<List<School>> getSchools() async {
    final res = await http
        .get(Uri.parse('$_base/get_schools.php'), headers: _headers)
        .timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => School.fromJson(e)).toList();
  }

  /// Single school by ID.
  static Future<School> getSchoolById(int id) async {
    final uri = Uri.parse('$_base/get_school.php').replace(
      queryParameters: {'id': id.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    return School.fromJson(body['data']);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // LANDLORDS
  // ───────────────────────────────────────────────────────────────────────────

  /// Single landlord by ID.
  static Future<Landlord> getLandlordById(int id) async {
    final uri = Uri.parse('$_base/get_landlord.php').replace(
      queryParameters: {'id': id.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    return Landlord.fromJson(body['data']);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // FACILITIES
  // ───────────────────────────────────────────────────────────────────────────

  /// All facilities for a hostel.
  static Future<List<Facility>> getFacilities(int hostelId) async {
    final uri = Uri.parse('$_base/get_facilities.php').replace(
      queryParameters: {'hostel_id': hostelId.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    final list = (body['data'] as List?) ?? [];
    return list.map((e) => Facility.fromJson(e)).toList();
  }

  // ───────────────────────────────────────────────────────────────────────────
  // AUTH  (UserModel)
  // ───────────────────────────────────────────────────────────────────────────

  /// Login — returns the logged-in user on success.
  static Future<UserModel> login(String email, String password) async {
    final res = await http
        .post(
          Uri.parse('$_base/login.php'),
          headers: _headers,
          body: json.encode({'email': email, 'password': password}),
        )
        .timeout(_timeout);

    final body = _parseResponse(res);
    return UserModel.fromJson(body['data']);
  }

  /// Register a new user — returns the created user.
  static Future<UserModel> register(Map<String, dynamic> payload) async {
    final res = await http
        .post(
          Uri.parse('$_base/register.php'),
          headers: _headers,
          body: json.encode(payload),
        )
        .timeout(_timeout);

    final body = _parseResponse(res);
    return UserModel.fromJson(body['data']);
  }

  /// Fetch user profile by ID.
  static Future<UserModel> getUserById(int id) async {
    final uri = Uri.parse('$_base/get_user.php').replace(
      queryParameters: {'id': id.toString()},
    );
    final res = await http.get(uri, headers: _headers).timeout(_timeout);

    final body = _parseResponse(res);
    return UserModel.fromJson(body['data']);
  }

  /// Update user profile.
  static Future<UserModel> updateUser(
      int id, Map<String, dynamic> payload) async {
    final res = await http
        .post(
          Uri.parse('$_base/update_user.php'),
          headers: _headers,
          body: json.encode({'id': id, ...payload}),
        )
        .timeout(_timeout);

    final body = _parseResponse(res);
    return UserModel.fromJson(body['data']);
  }
}
