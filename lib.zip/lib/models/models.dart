// ─── Hostel ───────────────────────────────────────────────────
class Hostel {
  final int id;
  final int landlordId;
  final String landlordName;
  final String landlordCode;
  final String hostelName;
  final String hostelCode;
  final String? address;
  final String? town;
  final int schoolId;
  final String? description;
  final int roomsAvailable;
  final String? image;
  final String? images;
  final String phone;
  final String durationType;
  final String paymentMomo;
  final String paymentCash;
  final String paymentBank;
  final String paymentOther;
  final String? googleMap;

  /// For API joins
  final String? schoolName;
  final String? schoolShortName;
  final String? priceRange;

  Hostel({
    required this.id,
    required this.landlordId,
    required this.landlordName,
    required this.landlordCode,
    required this.hostelName,
    required this.hostelCode,
    this.address,
    this.town,
    required this.schoolId,
    this.description,
    required this.roomsAvailable,
    this.image,
    this.images,
    required this.phone,
    required this.durationType,
    required this.paymentMomo,
    required this.paymentCash,
    required this.paymentBank,
    required this.paymentOther,
    this.googleMap,
    this.schoolName,
    this.schoolShortName,
    this.priceRange,
  });

  factory Hostel.fromJson(Map<String, dynamic> json) => Hostel(
        id: int.parse(json['id'].toString()),
        landlordId: int.parse(json['landlord_id'].toString()),
        landlordName: json['landlord_name'] ?? '',
        landlordCode: json['landlord_code'] ?? '',
        hostelName: json['hostel_name'] ?? '',
        hostelCode: json['hostel_code'] ?? '',
        address: json['address'],
        town: json['town'],
        schoolId: int.parse(json['school_id'].toString()),
        description: json['description'],
        roomsAvailable: int.parse(json['rooms_available']?.toString() ?? '0'),
        image: json['image'],
        images: json['images'],
        phone: json['phone'] ?? '',
        durationType: json['duration_type'] ?? 'per year',
        paymentMomo: json['payment_momo'] ?? '',
        paymentCash: json['payment_cash'] ?? '',
        paymentBank: json['payment_bank'] ?? '',
        paymentOther: json['payment_other'] ?? '',
        googleMap: json['google_map'],
        schoolName: json['school_name'],
        schoolShortName: json['short_name'],
        priceRange: json['price_range'],
      );
}

// ─── Room ─────────────────────────────────────────────────────
class Room {
  final int id;
  final int hostelId;
  final String hostelName;
  final String hostelCode;
  final String roomNumber;
  final String type;
  final int capacity;
  final double price;
  final bool available;
  final String? image;
  final String? images;
  final int booked;

  Room({
    required this.id,
    required this.hostelId,
    required this.hostelName,
    required this.hostelCode,
    required this.roomNumber,
    required this.type,
    required this.capacity,
    required this.price,
    required this.available,
    this.image,
    this.images,
    required this.booked,
  });

  factory Room.fromJson(Map<String, dynamic> json) => Room(
        id: int.parse(json['id'].toString()),
        hostelId: int.parse(json['hostel_id'].toString()),
        hostelName: json['hostel_name'] ?? '',
        hostelCode: json['hostel_code'] ?? '',
        roomNumber: json['room_number'] ?? '',
        type: json['type'] ?? '',
        capacity: int.parse(json['capacity'].toString()),
        price: double.parse(json['price'].toString()),
        available: json['available'].toString() == '1',
        image: json['image'],
        images: json['images'],
        booked: int.parse(json['booked']?.toString() ?? '0'),
      );
}

// ─── User ─────────────────────────────────────────────────────
class UserModel {
  final int id;
  final String username;
  final String email;
  final String phone;
  final String role;

  UserModel({
    required this.id,
    required this.username,
    required this.email,
    required this.phone,
    required this.role,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: int.parse(json['id'].toString()),
        username: json['username'] ?? '',
        email: json['email'] ?? '',
        phone: json['phone'] ?? '',
        role: json['role'] ?? 'student',
      );
}

// ─── Booking ──────────────────────────────────────────────────
class Booking {
  final int id;
  final int roomId;
  final int hostelId;
  final String hostelCode;
  final String hostelName;
  final String roomNumber;
  final String name;
  final String email;
  final String phone;
  final String school;
  final String? schoolId;
  final bool notStudent;
  final String? notes;
  final String paymentMethod;
  final String paymentInfo;
  final String status;
  final String bookedAt;
  final int slotsBooked;

  Booking({
    required this.id,
    required this.roomId,
    required this.hostelId,
    required this.hostelCode,
    required this.hostelName,
    required this.roomNumber,
    required this.name,
    required this.email,
    required this.phone,
    required this.school,
    this.schoolId,
    required this.notStudent,
    this.notes,
    required this.paymentMethod,
    required this.paymentInfo,
    required this.status,
    required this.bookedAt,
    required this.slotsBooked,
  });

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
        id: int.parse(json['id'].toString()),
        roomId: int.parse(json['room_id'].toString()),
        hostelId: int.parse(json['hostel_id'].toString()),
        hostelCode: json['hostel_code'] ?? '',
        hostelName: json['hostel_name'] ?? '',
        roomNumber: json['room_number'] ?? '',
        name: json['name'] ?? '',
        email: json['email'] ?? '',
        phone: json['phone'] ?? '',
        school: json['school'] ?? '',
        schoolId: json['school_id'],
        notStudent: json['not_student'].toString() == '1',
        notes: json['notes'],
        paymentMethod: json['payment_method'] ?? '',
        paymentInfo: json['payment_info'] ?? '',
        status: json['status'] ?? 'booked',
        bookedAt: json['booked_at'] ?? '',
        slotsBooked: int.parse(json['slots_booked']?.toString() ?? '1'),
      );
}

// ─── School ───────────────────────────────────────────────────
class School {
  final int id;
  final String fullName;
  final String shortName;
  final String town;
  final String schoolCode;

  School({
    required this.id,
    required this.fullName,
    required this.shortName,
    required this.town,
    required this.schoolCode,
  });

  factory School.fromJson(Map<String, dynamic> json) => School(
        id: int.parse(json['id'].toString()),
        fullName: json['full_name'] ?? '',
        shortName: json['short_name'] ?? '',
        town: json['town'] ?? '',
        schoolCode: json['school_code'] ?? '',
      );
}

// ─── Landlord ─────────────────────────────────────────────────
class Landlord {
  final int id;
  final String fullName;
  final String email;
  final String phone;
  final String? address;
  final String landlordCode;

  Landlord({
    required this.id,
    required this.fullName,
    required this.email,
    required this.phone,
    this.address,
    required this.landlordCode,
  });

  factory Landlord.fromJson(Map<String, dynamic> json) => Landlord(
        id: int.parse(json['id'].toString()),
        fullName: json['full_name'] ?? '',
        email: json['email'] ?? '',
        phone: json['phone'] ?? '',
        address: json['address'],
        landlordCode: json['landlord_code'] ?? '',
      );
}

// ─── Facility ─────────────────────────────────────────────────
class Facility {
  final int id;
  final int hostelId;
  final String hostelCode;
  final String hostelName;
  final String facilityName;

  Facility({
    required this.id,
    required this.hostelId,
    required this.hostelCode,
    required this.hostelName,
    required this.facilityName,
  });

  factory Facility.fromJson(Map<String, dynamic> json) => Facility(
        id: int.parse(json['id'].toString()),
        hostelId: int.parse(json['hostel_id'].toString()),
        hostelCode: json['hostel_code'] ?? '',
        hostelName: json['hostel_name'] ?? '',
        facilityName: json['facility_name'] ?? '',
      );
}
