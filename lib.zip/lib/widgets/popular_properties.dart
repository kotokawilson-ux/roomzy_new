// lib/widgets/popular_properties.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import 'package:responsive_framework/responsive_framework.dart';

import '../core/constants/app_constants.dart';
import '../core/theme/app_theme.dart';
import '../models/models.dart';
import '../services/api_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Image URL helper (works for web, Android, iOS automatically)
// Prepends imageBase when path is relative, keeps absolute URLs intact
// Falls back to a placeholder if path is empty or null
// ─────────────────────────────────────────────────────────────────────────────
String buildImageUrl(String? path) {
  // Default placeholder if no image is available
  const placeholder =
      'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600&q=80';

  if (path == null || path.trim().isEmpty) return placeholder;

  // If path already has http/https, return as is
  if (path.startsWith('http')) return path;

  // Otherwise, prepend base URL dynamically
  final base = AppConstants.imageBase.endsWith('/')
      ? AppConstants.imageBase.substring(0, AppConstants.imageBase.length - 1)
      : AppConstants.imageBase;

  return '$base/$path';
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal load-state enum
// ─────────────────────────────────────────────────────────────────────────────
enum _LoadState { loading, success, empty, error }

// ─────────────────────────────────────────────────────────────────────────────
// PopularProperties
// Fetches the featured hostels and renders them in a horizontal scroll list
// (mobile / tablet) or a responsive grid (desktop).
// ─────────────────────────────────────────────────────────────────────────────
class PopularProperties extends StatefulWidget {
  const PopularProperties({super.key});

  @override
  State<PopularProperties> createState() => _PopularPropertiesState();
}

class _PopularPropertiesState extends State<PopularProperties>
    with SingleTickerProviderStateMixin {
  // ── State ──────────────────────────────────────────────────────────────────
  List<Hostel> _hostels = [];
  _LoadState _loadState = _LoadState.loading;
  String _errorMessage = '';

  late final AnimationController _animController;
  final ScrollController _scrollController = ScrollController();

  // ── Lifecycle ──────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _loadHostels();
  }

  @override
  void dispose() {
    _animController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ── Data ───────────────────────────────────────────────────────────────────
  Future<void> _loadHostels() async {
    if (!mounted) return;
    setState(() {
      _loadState = _LoadState.loading;
      _errorMessage = '';
    });

    try {
      final fetched = await ApiService.getFeaturedHostels();
      if (!mounted) return;

      if (fetched.isEmpty) {
        setState(() => _loadState = _LoadState.empty);
      } else {
        setState(() {
          _hostels = fetched;
          _loadState = _LoadState.success;
        });
        _animController
          ..reset()
          ..forward();
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _loadState = _LoadState.error;
        _errorMessage = e.message;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadState = _LoadState.error;
        _errorMessage = 'Check your internet connection and try again.';
      });
    }
  }

  // ── Scroll helpers ─────────────────────────────────────────────────────────
  void _scrollNext() => _scrollController.animateTo(
        _scrollController.offset + 270,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
      );

  void _scrollPrev() => _scrollController.animateTo(
        _scrollController.offset - 270,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
      );

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isDesktop = ResponsiveBreakpoints.of(context).largerThan(TABLET);

    return Container(
      padding: EdgeInsets.symmetric(
        vertical: 60,
        horizontal: isDesktop ? 48 : 20,
      ),
      color: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Section heading ─────────────────────────────────────────────
          const Text(
            'Top Hostels / Apartments',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w700,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Browse the latest student hostels and apartments near your school',
            style: TextStyle(
              fontSize: 14,
              color: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
            ),
          ),
          const SizedBox(height: 32),

          // ── Content (switches between states) ───────────────────────────
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: KeyedSubtree(
              key: ValueKey(_loadState),
              child: _buildContent(isDark, isDesktop),
            ),
          ),

          // ── "View All" button ────────────────────────────────────────────
          if (_loadState == _LoadState.success) ...[
            const SizedBox(height: 32),
            Center(
              child: OutlinedButton(
                onPressed: () => context.go('/hostels'),
                style: OutlinedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
                  side: const BorderSide(color: AppColors.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: const Text(
                  'View All Hostels',
                  style: TextStyle(color: AppColors.primary),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── State dispatcher ───────────────────────────────────────────────────────
  Widget _buildContent(bool isDark, bool isDesktop) {
    switch (_loadState) {
      case _LoadState.loading:
        return _buildShimmer(isDark, isDesktop);
      case _LoadState.error:
        return _buildError();
      case _LoadState.empty:
        return _buildEmpty();
      case _LoadState.success:
        return isDesktop ? _buildGrid(isDark) : _buildHorizontalList(isDark);
    }
  }

  // ── Desktop grid ───────────────────────────────────────────────────────────
  Widget _buildGrid(bool isDark) {
    final isWide = ResponsiveBreakpoints.of(context).largerThan(DESKTOP);
    final cols = isWide ? 4 : 3;
    const totalPadding = 96.0; // 48 * 2
    final totalGap = (cols - 1) * 20.0;
    final cardWidth =
        (MediaQuery.of(context).size.width - totalPadding - totalGap) / cols;

    return Wrap(
      spacing: 20,
      runSpacing: 20,
      children: _hostels
          .asMap()
          .entries
          .map((entry) => _AnimatedCard(
                index: entry.key,
                controller: _animController,
                child: SizedBox(
                  width: cardWidth,
                  child: HostelCard(hostel: entry.value, isDark: isDark),
                ),
              ))
          .toList(),
    );
  }

  // ── Mobile horizontal list ─────────────────────────────────────────────────
  Widget _buildHorizontalList(bool isDark) {
    return SizedBox(
      height: 390,
      child: Stack(
        children: [
          ListView.builder(
            controller: _scrollController,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.only(bottom: 4),
            itemCount: _hostels.length,
            itemBuilder: (context, index) {
              return _AnimatedCard(
                index: index,
                controller: _animController,
                child: Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: SizedBox(
                    width: 252,
                    child: HostelCard(hostel: _hostels[index], isDark: isDark),
                  ),
                ),
              );
            },
          ),
          // Scroll arrows
          Positioned(
            bottom: 0,
            right: 0,
            child: Row(
              children: [
                _ArrowButton(
                  icon: Icons.arrow_back_ios_new_rounded,
                  onTap: _scrollPrev,
                ),
                const SizedBox(width: 8),
                _ArrowButton(
                  icon: Icons.arrow_forward_ios_rounded,
                  onTap: _scrollNext,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Shimmer skeleton ───────────────────────────────────────────────────────
  Widget _buildShimmer(bool isDark, bool isDesktop) {
    final base = isDark ? Colors.grey[800]! : Colors.grey[300]!;
    final highlight = isDark ? Colors.grey[700]! : Colors.grey[100]!;
    final card = isDark ? AppColors.darkCard : AppColors.lightSurface;

    if (isDesktop) {
      return Wrap(
        spacing: 20,
        runSpacing: 20,
        children: List.generate(
          6,
          (_) => Shimmer.fromColors(
            baseColor: base,
            highlightColor: highlight,
            child: Container(
              width: 280,
              height: 360,
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),
      );
    }

    return SizedBox(
      height: 390,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 5,
        itemBuilder: (_, __) => Padding(
          padding: const EdgeInsets.only(right: 16),
          child: Shimmer.fromColors(
            baseColor: base,
            highlightColor: highlight,
            child: Container(
              width: 252,
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Error state ────────────────────────────────────────────────────────────
  Widget _buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 48, color: Colors.grey),
            const SizedBox(height: 12),
            const Text(
              'Could not load hostels',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Text(
              _errorMessage,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _loadHostels,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Try Again'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Empty state ────────────────────────────────────────────────────────────
  Widget _buildEmpty() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.apartment_rounded, size: 48, color: Colors.grey),
            SizedBox(height: 12),
            Text(
              'No hostels available yet',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _AnimatedCard — staggered fade+slide-up entrance for each card
// ─────────────────────────────────────────────────────────────────────────────
class _AnimatedCard extends StatelessWidget {
  final int index;
  final AnimationController controller;
  final Widget child;

  const _AnimatedCard({
    required this.index,
    required this.controller,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    // Stagger: each card starts 80ms after the previous, capped to avoid overlap
    final start = (index * 0.08).clamp(0.0, 0.7);
    final end = (start + 0.4).clamp(0.0, 1.0);

    final animation = CurvedAnimation(
      parent: controller,
      curve: Interval(start, end, curve: Curves.easeOut),
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) => Opacity(
        opacity: animation.value,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - animation.value)),
          child: child,
        ),
      ),
      child: child,
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _ArrowButton — circular prev / next scroll button
// ─────────────────────────────────────────────────────────────────────────────
class _ArrowButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ArrowButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.92),
      shape: const CircleBorder(),
      elevation: 4,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, color: Colors.black87, size: 18),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// HostelCard — single hostel tile
// ─────────────────────────────────────────────────────────────────────────────
class HostelCard extends StatelessWidget {
  final Hostel hostel;
  final bool isDark;

  const HostelCard({required this.hostel, required this.isDark, super.key});

  @override
  Widget build(BuildContext context) {
    final cardColor = isDark ? AppColors.darkCard : AppColors.lightSurface;
    final textPrimary =
        isDark ? AppColors.darkTextPrimary : AppColors.lightTextPrimary;
    final textSecondary =
        isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;
    final textMuted =
        isDark ? AppColors.darkTextMuted : AppColors.lightTextMuted;

    final imageUrl = buildImageUrl(hostel.image);
    final available = hostel.roomsAvailable > 0;

    return GestureDetector(
      onTap: () => context.go('/hostels/${hostel.id}'),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(isDark ? 0.3 : 0.07),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Hostel image ───────────────────────────────────────────────
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
              child: Stack(
                children: [
                  CachedNetworkImage(
                    imageUrl: imageUrl,
                    height: 160,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Shimmer.fromColors(
                      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
                      highlightColor:
                          isDark ? Colors.grey[700]! : Colors.grey[100]!,
                      child: Container(height: 160, color: cardColor),
                    ),
                    errorWidget: (_, __, ___) => Container(
                      height: 160,
                      color: AppColors.primary.withOpacity(0.08),
                      child: const Center(
                        child: Icon(
                          Icons.apartment_rounded,
                          size: 40,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ),

                  // Available / Full badge
                  Positioned(
                    top: 10,
                    right: 10,
                    child: _Badge(
                      label: available ? 'Available' : 'Full',
                      color: available
                          ? Colors.green.shade600
                          : Colors.red.shade600,
                    ),
                  ),

                  // Town label
                  if (hostel.town != null && hostel.town!.isNotEmpty)
                    Positioned(
                      bottom: 10,
                      left: 10,
                      child: _Badge(
                        label: hostel.town!,
                        color: Colors.black54,
                      ),
                    ),
                ],
              ),
            ),

            // ── Details ────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Hostel name
                  Text(
                    hostel.hostelName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),

                  // Price range
                  if (hostel.priceRange != null)
                    Text(
                      hostel.priceRange!,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primary,
                      ),
                    ),
                  const SizedBox(height: 4),

                  // Address
                  if (hostel.address != null && hostel.address!.isNotEmpty)
                    _IconRow(
                      icon: Icons.location_on_outlined,
                      label: hostel.address!,
                      color: textMuted,
                    ),
                  const SizedBox(height: 3),

                  // School
                  if (hostel.schoolName != null) ...[
                    _IconRow(
                      icon: Icons.school_outlined,
                      label: hostel.schoolShortName != null
                          ? '${hostel.schoolName} (${hostel.schoolShortName})'
                          : hostel.schoolName!,
                      color: textSecondary,
                    ),
                    const SizedBox(height: 3),
                  ],

                  // Availability
                  _IconRow(
                    icon: Icons.door_front_door_outlined,
                    label: available
                        ? '${hostel.roomsAvailable} room${hostel.roomsAvailable > 1 ? 's' : ''} available'
                        : 'No rooms available',
                    color:
                        available ? Colors.green.shade600 : Colors.red.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                  const SizedBox(height: 10),

                  // CTA button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => context.go('/hostels/${hostel.id}'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        'See Details',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _Badge — small pill overlay on card images
// ─────────────────────────────────────────────────────────────────────────────
class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _IconRow — icon + single-line text used inside HostelCard details
// ─────────────────────────────────────────────────────────────────────────────
class _IconRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final FontWeight fontWeight;

  const _IconRow({
    required this.icon,
    required this.label,
    required this.color,
    this.fontWeight = FontWeight.normal,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 12, color: color),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              color: color,
              fontWeight: fontWeight,
            ),
          ),
        ),
      ],
    );
  }
}
