import 'package:flutter/material.dart';

class HostelDetailScreen extends StatelessWidget {
  final int hostelId;
  const HostelDetailScreen({super.key, required this.hostelId});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('Hostel $hostelId Detail - Coming Soon')),
    );
  }
}
