import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';
import '../models/models.dart';

/// ─────────────────────────────────────────────────────────────
/// AuthService
/// Manages user session state (login, logout, persist session).
/// API calls are stubbed — wire them up when building auth screens.
/// ─────────────────────────────────────────────────────────────
class AuthService extends ChangeNotifier {
  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isLoggedIn => _currentUser != null;
  String? get errorMessage => _errorMessage;
  String? get userRole => _currentUser?.role;

  // ── Load saved session on app start ───────────────────────
  Future<void> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    final loggedIn = prefs.getBool(AppConstants.keyIsLoggedIn) ?? false;

    if (loggedIn) {
      _currentUser = UserModel(
        id: prefs.getInt(AppConstants.keyUserId) ?? 0,
        username: prefs.getString(AppConstants.keyUserName) ?? '',
        email: prefs.getString(AppConstants.keyUserEmail) ?? '',
        phone: '',
        role: prefs.getString(AppConstants.keyUserRole) ??
            AppConstants.roleStudent,
      );
      notifyListeners();
    }
  }

  // ── Persist session to SharedPreferences ──────────────────
  Future<void> _saveSession(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.keyIsLoggedIn, true);
    await prefs.setInt(AppConstants.keyUserId, user.id);
    await prefs.setString(AppConstants.keyUserName, user.username);
    await prefs.setString(AppConstants.keyUserEmail, user.email);
    await prefs.setString(AppConstants.keyUserRole, user.role);
  }

  // ── Student login (stub — implement when building auth) ───
  Future<bool> loginStudent(String email, String password) async {
    _setLoading(true);
    // TODO: call ApiService.login(email, password) when auth is ready
    _setLoading(false);
    _errorMessage = 'Login not implemented yet';
    notifyListeners();
    return false;
  }

  // ── Landlord login (stub) ─────────────────────────────────
  Future<bool> loginLandlord(String email, String password) async {
    _setLoading(true);
    // TODO: call ApiService.login(email, password) when auth is ready
    _setLoading(false);
    _errorMessage = 'Login not implemented yet';
    notifyListeners();
    return false;
  }

  // ── Admin login (stub) ────────────────────────────────────
  Future<bool> loginAdmin(String email, String password) async {
    _setLoading(true);
    // TODO: call ApiService.login(email, password) when auth is ready
    _setLoading(false);
    _errorMessage = 'Login not implemented yet';
    notifyListeners();
    return false;
  }

  // ── Register student (stub) ───────────────────────────────
  Future<bool> registerStudent({
    required String username,
    required String email,
    required String phone,
    required String password,
  }) async {
    _setLoading(true);
    // TODO: call ApiService.register(...) when auth is ready
    _setLoading(false);
    _errorMessage = 'Registration not implemented yet';
    notifyListeners();
    return false;
  }

  // ── Logout ────────────────────────────────────────────────
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _currentUser = null;
    _errorMessage = null;
    notifyListeners();
  }

  // ── Internal helper ───────────────────────────────────────
  void _setLoading(bool value) {
    _isLoading = value;
    _errorMessage = null;
    notifyListeners();
  }
}
