import 'package:flutter/material.dart';
import 'package:responsive_framework/responsive_framework.dart';

import 'package:roomzy_find/widgets/navbar.dart';
import 'package:roomzy_find/widgets/hero_section.dart';
import 'package:roomzy_find/widgets/popular_properties.dart';
import 'package:roomzy_find/widgets/features_section.dart';
import 'package:roomzy_find/widgets/about_section.dart';
import 'package:roomzy_find/widgets/testimonials_section.dart';
import 'package:roomzy_find/widgets/footer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final responsive = ResponsiveBreakpoints.of(context);

    // Adaptive horizontal padding
    final horizontalPadding = responsive.isMobile
        ? 16.0
        : responsive.isTablet
            ? 32.0
            : 48.0;

    return Scaffold(
      /// NAVBAR
      appBar: const Navbar(),

      /// MOBILE DRAWER
      endDrawer: const NavbarDrawer(),

      /// PAGE BODY
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                /// HERO SECTION (full width)
                HeroSection(),

                SizedBox(height: 40),

                /// POPULAR PROPERTIES (full width)
                PopularProperties(),

                SizedBox(height: 40),

                /// FEATURES SECTION (full width)
                FeaturesSection(),

                SizedBox(height: 60),

                /// ABOUT SECTION
                AboutSection(),

                SizedBox(height: 60),

                /// TESTIMONIALS
                TestimonialsSection(),

                SizedBox(height: 80),

                /// FOOTER
                Footer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
