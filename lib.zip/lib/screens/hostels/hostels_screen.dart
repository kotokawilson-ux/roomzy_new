import 'package:flutter/material.dart';
import 'package:responsive_framework/responsive_framework.dart';

import 'package:roomzy_find/widgets/navbar.dart';
import 'package:roomzy_find/widgets/hostels_hero.dart'; // New hero section
import 'package:roomzy_find/widgets/hostels_list.dart'; // Main content (main-prop.php)
import 'package:roomzy_find/widgets/footer.dart';

class HostelsScreen extends StatelessWidget {
  const HostelsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final responsive = ResponsiveBreakpoints.of(context);

    // Adaptive horizontal padding
    final horizontalPadding = responsive.isMobile
        ? 16.0
        : responsive.isTablet
            ? 32.0
            : 48.0;

    return Scaffold(
      /// NAVBAR
      appBar: const Navbar(),

      /// MOBILE DRAWER
      endDrawer: const NavbarDrawer(),

      /// PAGE BODY
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),

                /// HERO SECTION (hostels-specific)
                HostelsHero(),

                const SizedBox(height: 40),

                /// MAIN CONTENT (list of hostels)
                const HostelsList(),

                const SizedBox(height: 60),

                /// FOOTER
                const Footer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
