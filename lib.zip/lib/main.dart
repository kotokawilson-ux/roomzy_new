import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:responsive_framework/responsive_framework.dart';

import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'services/auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load saved session before app starts
  final authService = AuthService();
  await authService.loadSession();

  runApp(
    ChangeNotifierProvider<AuthService>.value(
      value: authService,
      child: const RoomzyFindApp(),
    ),
  );
}

class RoomzyFindApp extends StatelessWidget {
  const RoomzyFindApp({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();

    return MaterialApp.router(
      title: 'RoomzyFind',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,

      // Router configured with AuthService
      routerConfig: AppRouter.router(authService),

      // Responsive breakpoints and adaptive shell
      builder: (context, child) => ResponsiveBreakpoints.builder(
        child: _AppShell(child: child!),
        breakpoints: const [
          Breakpoint(start: 0, end: 450, name: MOBILE),
          Breakpoint(start: 451, end: 800, name: TABLET),
          Breakpoint(start: 801, end: 1280, name: DESKTOP),
          Breakpoint(start: 1281, end: double.infinity, name: '4K'),
        ],
      ),
    );
  }
}

/// ─────────────────────────────────────────────
/// Adaptive App Shell
/// Mobile: full width
/// Tablet/Desktop/Web: centered max-width
/// ─────────────────────────────────────────────
class _AppShell extends StatelessWidget {
  final Widget child;
  const _AppShell({required this.child});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    // Mobile: full width
    if (screenWidth <= 600) return child;

    // Tablet / Desktop / Web: adaptive max width
    double maxWidth;
    if (screenWidth <= 1280) {
      maxWidth = 800;
    } else {
      maxWidth = 1200;
    }

    return Scaffold(
      backgroundColor: const Color(0xFF00204A),
      body: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: maxWidth),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: child,
          ),
        ),
      ),
    );
  }
}
